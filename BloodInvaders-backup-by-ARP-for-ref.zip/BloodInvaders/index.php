<?php
session_start();

//echo $_SESSION['uname'];
?>

<!DOCTYPE html>
<html>
<head><meta charset="UTF-8">
  <meta name="description" content="Commentary on latest news, celebrities, politics, and gossip">
  <meta name="keywords" content="news,celebrities,politics,gossip"><!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-44249223-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-44249223-13');
</script>


<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="picklestyle.css">	

</head>
<body>

<div class="header">
  <h1>Spoiled Pickle</h1>
</div>

<div class="row">
  <div class="col-3 col-s-3 menu">
    <ul>
      
	<?php include 'picklepublicmenu.php';?>
	  <?php include 'picklemenu.php';?>
		
	<!--	<li><a href = "login2.php">Log In</a></li>-->
    </ul>
	  <!--
	  <a href = "coronavirustracker.php"><h2>Coronavirus Tracker</h2><br><img src = "images/coronavirusmap.png" style="display:block"/></a><br>
	  <br><br>
	  -->
	<!--  <a href = "popquiz.php"><img src = "images/popquizgraphic4.gif" style="display:block"/></a>
      -->
    
	  <br><br>
	   <h1><div style="margin	: auto"><a href="DunkingBooth2024/dunkingbooth.php">What 2024 GOP Candidate Do You Want To Quit?  Play Now!</a></div></h1>
      <p>
		     <a href = "http://www.spoiledpickle.com/DunkingBooth2024/dunkingbooth.php"><img src = "images/dunkdesantis.jpeg"/></a>
	  </p><br><br>
	  
	  
		  	  	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="BloodInvaders/bloodinvders2.php">Blood Invaders PC game now available for members only!</a></div></h1>
      <p>
		  <a href="BloodInvaders/bloodinvders2.php"><img src ="images/BloodInvaders/bloodinvadersthumb.png" /></a>
	  </p><br><br>  
	  
	  	  	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="ladiesreally.php">Scantily Clad Women Fight Over A Man At The Casino</a></div></h1>
      <p>
		  <a href="ladiesreally.php"><img src ="images/ladiesreally.png" /></a>
	  </p><br><br>
	  
	  	  <hr style="height: 5px" color="#C75000"><br>
	  <br><div style="width:100%;background-color:black;color:white;font-size:25px;text-align:center">Play Joker's Wild<br>
       <a href = "jokerswildfinal.php"><img src = "images/joker.png" style="display:block"/></a>
      </div>
      <br>
	  <br><br>
	  

	  
	  
	  
	   <hr style="height: 5px" color="#C75000"><br>
	  <div style="margin: auto; color:white"><a href ="http://www.spoiledpickle.com/picklesignup.php"> Enjoy Great Commentary, Food, and Gossip with exclusive members only content.   Click here to sign up! </a> </div>
      <br>
	<hr style="height: 5px" color="#C75000"><br>
	  <p>
		  <img src ="images/cryptochroniclesthumb2.png" onClick="window.location='https://youtu.be/kwCIJmaKCEQ';return false;"/>
		  
		  <a href="https://www.amazon.com/dp/B0B5MH6TK9?&linkCode=li3&tag=rougride2016-20&linkId=927b7326f8803ce29a3378a7b313f173&language=en_US&ref_=as_li_ss_il" target="_blank"><h1 style="color:white">SUADEX Steel Toe Shoes for Men Indestructible Work Shoes for Women </h1><br>
		  <img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B0B5MH6TK9&Format=_SL250_&ID=AsinImage&MarketPlace=US&ServiceVersion=20070822&WS=1&tag=rougride2016-20&language=en_US" ></a><img src="https://ir-na.amazon-adsystem.com/e/ir?t=rougride2016-20&language=en_US&l=li3&o=1&a=B0B5MH6TK9" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
	  </p>
	 
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin: auto"><a href="uvalde.php">It's Time America Had A Serious Discussion About Gun Control!</a></div></h1>
      <p>
		  <a href="uvalde.php"><img src="images/uvalde.png" /></a>
	  </p><br><br>
	  
	   <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin: auto"><a href="zucchinidevilchips.php">Zucchini Devil Chips!</a></div></h1>
      <p>
		  <a href="zucchinidevilchips.php"><img src ="images/zucchinidevilchips/IMG_8163.jpg" /></a>
	  </p><br><br>
	  
	  
	   

	  
  </div>

  <div class="col-6 col-s-9">
    <h1>Here's the Deal.</h1>
    <p>With all the foolishness going on in the world.  We got to talk (gossip) about it.  Every now and then you can chalk it up to Darwinism but the truth is now adays it's starting to look like there's not a day that goes by where something dumb or extra doesn't happen.  <br><br>  Well, on this site, we're going to talk about it.  Hopefully, you'll enjoy our commentary.  With that, kick back, have glance and let's get into it.</p>
	
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="http://www.spoiledpickle.com/DunkingBooth2024/dunkingbooth.php">Does Mr. Trump Got You Buggered?  Play Now!</a></div></h1>
      <p>
		  <a href="http://www.spoiledpickle.com/DunkingBooth2024/dunkingbooth.php"><img src ="images/dunktrump.jpeg" /></a>
	  </p><br><br>
	
	
	 <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="unelectable.php">At What Point Does Someone Become Unelectable?</a></div></h1>
      <p>
		  <a href="unelectable.php"><img src ="images/trump.png" /></a>
	  </p><br><br>
	  
	  	  	  

	  	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="tailarouse.php">Taila Rouse Is A Modern Day Rosa Parks.</a></div></h1>
      <p>
		  <a href="tailarouse.php"><img src ="images/tailarouse.png" /></a>
	  </p><br><br>
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="harrisvp.php">Leave Vice President Kamala Harris Alone! Let Her Do Her Job!</a></div></h1>
      <p>
		  <a href="harrisvp.php"><img src ="images/harrisvp.png" /></a>
	  </p><br><br>
	  
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="sidehustle2023_1.php">Ten Reasons You Need A Side Hustle In 2023!</a></div></h1>
      <p>
		  <a href="sidehustle2023_1.php"><img src ="images/sidehustle2.jpg" /></a>
	  </p><br><br>
	  
	  
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="britneygriner.php">Brittney Griner Is The Luckiest Woman In The World!</a></div></h1>
      <p>
		  <a href="britneygriner.php"><img src ="images/brittneygriner.png" /></a>
	  </p><br><br>
	  
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="herschelconceeds.php">Herschel Walker's Campaign and Concession Speech Is A Lesson To All Would Be Politicians And Leaders.</a></div></h1>
      <p>
		  <a href="herschelconceeds.php"><img src ="images/herschelloss.png" /></a>
	  </p><br><br>
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="jan6erosion.php">The January 6th Hearings Could Start the Erosion Of Democracy!</a></div></h1>
      <p>
		  <a href="jan6erosion.php"><img src ="images/jan63.png" /></a>
	  </p><br><br>
	  
	  
	   <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="stopthemadness2.php">Mr. Putin, Nukes Are Not An Option!</a></div></h1>
      <p>
		  <a href="stopthemadness2.php"><img src ="images/nuke.png" /></a>
	  </p><br><br>
	  
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="Liz/lizcheneyrevenge.htm">Liz Cheney's Revenge!</a></div></h1>
      <p>
		  <a href="Liz/lizcheneyrevenge.htm"><img src ="Liz/liz.png" /></a>
	  </p><br><br>
	  
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="stopthemadness.php">Mr. Putin, What Are You Doing?  You Are Not A Barbarian!</a></div></h1>
      <p>
		  <a href="stopthemadness.php"><img src ="images/putintime.png" /></a>
	  </p><br><br>
	  
	  
 	   <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="bewareofthemetaverse.php">Beware Of The Metaverse!</a></div></h1>
      <p>
		  <a href="bewareofthemetaverse.php"><img src ="images/readyplayerone.png" /></a>
	  </p><br><br>
	  
	  
		  	   <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="leftovers.php">Teen Ager Left Amputated By Leftovers!</a></div></h1>
      <p>
		  <a href="leftovers.php"><img src ="images/lomein.png" /></a>
	  </p><br><br>
	  
	  
	  
	   <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="damndollarstore.php">Damn Dollar Store Is Gonna Get Us All Sick!</a></div></h1>
      <p>
		  <a href="damndollarstore.php"><img src ="images/ratdollar.png" /></a>
	  </p><br><br>
	  
	  
	  
	  
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="isthisyourmask.php">Is This Your Mask?</a></div></h1>
      <p>
		  <a href="isthisyourmask.php"><img src ="images/isthisyourmask/JPEG/IMG_3198.jpg" /></a>
	  </p><br><br>
	  
	  
	  
	   <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="socialsecurityreduction.php">Social Security: The Money They Stole!</a></div></h1>
      <p>
		  <a href="socialsecurityreduction.php"><img src ="images/socialsecuritygone.png" /></a>
	  </p><br><br>
	  
	  
	  
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin: auto"><a href="wheredothesepeoplecomefrom.php">Where Do These People Come From?</a></div></h1>
      <p>
		  <a href="wheredothesepeoplecomefrom.php"><img src ="images/wheredotheycomefrom/img5.png" /></a>
	  </p><br><br>
	  
	  
	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin: auto"><a href="lessufos.php">Where are the UFOs?</a></div></h1>
      <p>
		  <a href="lessufos.php"><img src ="images/flyingsaucer.png" /></a>
	  </p><br><br>
	  
	   <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin: auto"><a href="cultofzeus.php">The Cult of Zeus.</a></div></h1>
      <p>
		  <a href="cultofzeus.php"><img src ="images/Zeus.png" /></a>
	  </p><br><br>
	  
	 
	  
	  
	  

	  
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin: auto"><a href="trumpmovie1.htm">Trump on Toilets, Water, and China!</a></div></h1>
      <p>
		  
	<video width="100%" controls>
		<source src = "images/Trump on Toilets, Water, and China!.mp4" type="video/mp4">
	</video>
	  </p><br>
	  
	
	  <hr style="height: 5px" color="#C75000"><br>
	  
	  
	
  </div>
	
 
  <div class="col-3 col-s-12">
	
	  <div class="aside"  >
		  
		  <table cellspacing="3px">
			  <tr>
				  <td>
					  <a href="https://www.facebook.com/Spoiled-Pickle-108307937409209/?view_public_for=108307937409209"><img src="images/facebookicon.png" style="width:80%"/></a></td><td><a href="https://www.pinterest.com/spoiledpickle357/pins/"><img src ="images/pinteresticon.png" style="width:80%" /></a></td><td><img src ="images/pickleicon.png" style="width:80%"/></td></tr>
		  </table>
		
	  </div><br>
    <div class="aside">
		
      <h2>We Hate Politics!</h2>
      <p>Yeah, you guessed it.  We will not go easy on politicians on this site.  If they do something stupid, we ain't gonna let them off the hook.  If they have to get lit up here, it's going to be like fireworks in the sky.</p>
      <h2>We Love Celebrities!</h2>
      <p>You will always be able to come to our site and get an opinion on what Celebrities are up too.</p>
      <h2>News</h2>
      <p>Whether it be the law of the land or what's going on over seas, we might just weigh in.  If something dumb is going on, we're definitely going to speak upon it.</p>
    </div> <br>
	  
	  <div class = "aside">
	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="http://www.spoiledpickle.com/DunkingBooth2024/dunkingbooth.php">Is Vivek Getting On Your Nerves?  Play Now!</a></div></h1>
      <p>
		  <a href="http://www.spoiledpickle.com/DunkingBooth2024/dunkingbooth.php"><img src ="images/dunkramaswamy.jpeg" /></a>
	  </p><br><br>
	  	  	  <hr style="height: 5px" color="#C75000"><br>
	   <h1><div style="margin	: auto"><a href="foxxisback.php">Jamie Foxx Is On His Way Back!</a></div></h1>
      <p>
		  <a href="foxxisback.php"><img src ="images/jamiefoxx.png" /></a>
	  </p><br><br>
		  
		  <a href = "https://amzn.to/44Lwmnf"><h2 style="color:white">Beat The Heat!</h2><br><img border="0" src="images/glaciervest.gif" ></a>
		  
		  <br><br>
		  
		  
		  <a href="https://www.amazon.com/Duke-Cannon-Supply-Co-Accomplishment/dp/B07BFDF4R5?crid=35OUR11645QT0&keywords=duke+cannon+soap+bar&qid=1682693593&sprefix=duke+c%2Caps%2C130&sr=8-6&linkCode=li3&tag=rougride2016-20&linkId=820a383e0f8ade17b8be3d48568dc86e&language=en_US&ref_=as_li_ss_il" target="_blank"><h2 style="color:white">The Best Soap For A Man Ever Made!</h2><br><img border="0" src="images/dukecannonsoap.png" ></a>
		  
		  <!--
		  <a href="https://www.amazon.com/Duke-Cannon-Supply-Co-Accomplishment/dp/B07BFDF4R5?crid=35OUR11645QT0&keywords=duke+cannon+soap+bar&qid=1682693593&sprefix=duke+c%2Caps%2C130&sr=8-6&linkCode=li3&tag=rougride2016-20&linkId=820a383e0f8ade17b8be3d48568dc86e&language=en_US&ref_=as_li_ss_il" target="_blank"><h2 style="color:white">The Best Soap For A Man Ever Made!</h2><br><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B07BFDF4R5&Format=_SL250_&ID=AsinImage&MarketPlace=US&ServiceVersion=20070822&WS=1&tag=rougride2016-20&language=en_US" ></a><img src="https://ir-na.amazon-adsystem.com/e/ir?t=rougride2016-20&language=en_US&l=li3&o=1&a=B07BFDF4R5" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" /><br>
		  -->
		  
		  
		  
	   <a href="kingofcream.htm"><h2>Vote Your Favorite Ice Cream Brand!</h2><br><img src= "images/ice-cream.jpg"/></a>
	  <br>
	 <a href="http://spoiledpickle.com/smoked_stuffed_jalapeno_poppers.php"><h2>Recipe of the Month:<br>Smoked Stuffed Jalapeno Poppers</h2><br><img src= "recipes/smoked_stuffed_jalapeno_pepper/IMG_0232.jpg"/></a>
	  <br><br>
	  </div>
	  
	  <div class = "aside">
       <a href="https://apps.apple.com/es/app/ten-minute-toner/id1252597071?l=en"><h2>Are You Tired Of Being Fat?  Fight Back With Ten Minute Toner!</h2><br><img src= "images/tenminutetonerthumb.png" /></a>
	
	  </div><br><br>
	  
	  <div class = "aside">
	  <a href="http://www.fluseasonsurvival.com"><img src="images/healthy2.png"/></a>
	  </div><br><br>
	  <div style="color:white"><h2>Hello (from the Inside) An Adele Parody by Chris Mann</h2></div>
	  <iframe width="783" height="440" src="https://www.youtube.com/embed/M5azNpTwVk8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  </div><br><br>
	
	
	
	
	  
</div>

<div class="footer">
  <p>Spoiled Pickle is strickly commentary and meant for mature audience consumption.</p>
</div>

</body>
</html>

